## Contributing guidelines

All guidelines for contributing to the Seeed_Arduino_FreeRTOS repository can be found at [`How to contribute guideline`](https://github.com/Seeed-Studio/Seeed_Arduino_FreeRTOS/wiki/How_to_contribute).
